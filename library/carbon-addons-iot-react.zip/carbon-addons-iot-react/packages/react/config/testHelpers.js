export const emptyDOMTree = `
<html lang="en">
    <head>
        <title>a11y testing</title>
    </head>
    <body>
        <header>
            <nav>
                <a href="#main">Skip to content</a>
            </nav>
        </header>
        <main id="main"></main>
    </body>
</html>
`;
