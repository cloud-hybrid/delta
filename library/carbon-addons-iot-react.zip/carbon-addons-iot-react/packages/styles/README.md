# @ai-apps/styles

This package contains all of the styles from `carbon-addons-iot-react`.

Currently it is not intended to be edited directly, instead all the files here are kept up to date with changes in `carbon-addons-iot-react` via `yarn sync`. It's recommended to manually verify the contents of the package after every `yarn sync`, to ensure that changes have been applied correctly, and to remove any stale files (the `sync` command doesn't track deletions).
