const { vendor } = require('ai-apps-monorepo-utils');

vendor({
  packages: [
    '@carbon/themes',
    '@carbon/charts',
    '@carbon/motion',
    'carbon-components',
    'react-grid-layout',
    'react-resizable',
  ],
});
