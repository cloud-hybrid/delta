#!/usr/bin/env bash

set -e

yarn lint
