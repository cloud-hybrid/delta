const { vendor } = require('ai-apps-monorepo-utils');

vendor({
  packages: ['@ai-apps/styles'],
});
