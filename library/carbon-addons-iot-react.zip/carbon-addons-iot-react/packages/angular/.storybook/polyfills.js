import 'core-js/es7';

import 'zone.js/dist/zone';

import 'element-closest-polyfill';
