export { IconContentSwitcherOption } from './icon-content-switcher-option.directive';
export { IconContentSwitcher } from './icon-content-switcher.component';
export { IconContentSwitcherModule } from './icon-content-switcher.module';
