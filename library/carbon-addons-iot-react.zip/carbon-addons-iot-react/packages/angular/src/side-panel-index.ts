export { SidePanel } from './side-panel/side-panel.component';
export { SidePanelTitleDirective } from './side-panel/side-panel-title.directive';
export { SidePanelFooterDirective } from './side-panel/side-panel-footer.directive';
export { SidePanelModule } from './side-panel/side-panel.module';
