export { TabsModule } from './tabs/tabs.module';
export { TabComponent } from './tabs/tab.component';
export { TabsComponent } from './tabs/tabs.component';
export { TabDropdownComponent } from './tabs/tab-dropdown.component';
export { TabActionDirective } from './tabs/tab-action.directive';
export { TabActionsComponent } from './tabs/tab-actions.component';
export { TabHeader } from './tabs/tab-header.component';
