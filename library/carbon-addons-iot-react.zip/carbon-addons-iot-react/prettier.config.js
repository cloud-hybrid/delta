const prettierConfig = require('prettier-config-carbon'); // eslint-disable-line import/no-extraneous-dependencies

module.exports = prettierConfig;
